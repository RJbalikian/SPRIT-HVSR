.. w4h documentation master file, created by
   sphinx-quickstart on Mon Mar 11 15:35:33 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the documentation for SpRIT!
=======================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   sprit
   sprit.sprit_hvsr
   sprit.sprit_utils


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
