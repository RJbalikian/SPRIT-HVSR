sprit.sprit\_cli module
=======================

.. automodule:: sprit.sprit_cli
   :members:
   :undoc-members:
   :show-inheritance:
