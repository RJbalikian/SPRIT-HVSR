sprit.sprit\_jupyter\_UI module
===============================

.. automodule:: sprit.sprit_jupyter_UI
   :members:
   :undoc-members:
   :show-inheritance:
