sprit.sprit\_gui module
=======================

.. automodule:: sprit.sprit_gui
   :members:
   :undoc-members:
   :show-inheritance:
